define(['controller'], (Controller) => {

    return class extends Controller {

        defaultAction = 'index'

        actionIndex() {
            // This renders the main IBF Dashboard page
            this.main('custom:modules/ibf-dashboard/views/ibfdashboard', {
                title: 'IBF Dashboard'
            });
        }
    }
});
