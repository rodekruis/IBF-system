define(['controller'], (Controller) => {

    return class extends Controller {

        defaultAction = 'index'

        actionIndex() {
            // Add body class for CSS targeting
            document.body.classList.add('action-ibfdashboard');
            
            // This renders the main IBF Dashboard page
            this.main('ibf-dashboard:views/ibfdashboard', {
                title: 'IBF Dashboard'
            });
        }

        onRemove() {
            // Clean up body class when leaving the view
            document.body.classList.remove('action-ibfdashboard');
        }
    }
});
