define(['view'], (View) => {

    return class extends View {

        // Use inline template for full control
        templateContent = `
            <style>
                /* Hide EspoCRM page elements when viewing IBF Dashboard */
                body.action-ibfdashboard .page-header.espo-header,
                body.action-ibfdashboard .navbar,
                body.action-ibfdashboard .navbar-nav,
                body.action-ibfdashboard .breadcrumb-container,
                body.action-ibfdashboard nav.breadcrumb {
                    display: none !important;
                }

                /* Make content area take full viewport */
                body.action-ibfdashboard .main {
                    padding: 0 !important;
                    margin: 0 !important;
                    height: 100vh !important;
                    overflow: hidden !important;
                }

                body.action-ibfdashboard #content {
                    padding: 0 !important;
                    margin: 0 !important;
                    height: 100vh !important;
                    overflow: hidden !important;
                }

                .page-header {
                    padding: 20px 0 10px 0;
                    border-bottom: 1px solid #ddd;
                    margin-bottom: 20px;
                }

                /* Normal view styling when not in full action */
                body:not(.action-ibfdashboard) .page-header {
                    display: block;
                }

                body:not(.action-ibfdashboard) #content {
                    height: calc(100vh - 120px);
                }

                /* Full viewport styling when in IBF Dashboard action */
                body.action-ibfdashboard .page-header {
                    display: none;
                }

                body.action-ibfdashboard #content {
                    height: 100vh;
                }

                #content {
                    width: 100%;
                    position: relative;
                }

                #content iframe {
                    width: 100%;
                    height: 100%;
                    border: none;
                }

                .fullscreen-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 1000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: background-color 0.3s;
                }

                .fullscreen-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }

                .fullscreen-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 100vh;
                    background: white;
                    z-index: 9999;
                    display: none;
                }

                .fullscreen-overlay iframe {
                    width: 100%;
                    height: 100%;
                    border: none;
                }

                .fullscreen-overlay .close-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 10000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }

                .fullscreen-overlay .close-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }

                .loading-message {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    height: 100%;
                    font-size: 16px;
                    color: #666;
                }
            </style>

            <div class="page-header">
                <h3>IBF Dashboard</h3>
            </div>
            <div id="content">
                <button class="fullscreen-button" data-action="openFullscreen">
                    ⛶ Fullscreen
                </button>
                <div class="loading-message">Loading IBF Dashboard...</div>
                <iframe 
                    id="ibf-dashboard-main-frame" 
                    style="width: 100%; height: 100%; border: none; display: none;"
                    frameborder="0"
                    allowfullscreen 
                    allow="fullscreen">
                </iframe>
            </div>

            <div class="fullscreen-overlay" id="fullscreen-overlay-main">
                <button class="close-button" data-action="closeFullscreen">
                    ✕ Close
                </button>
                <iframe 
                    id="fullscreen-frame-main"
                    style="width: 100%; height: 100%; border: none;"
                    frameborder="0"
                    allowfullscreen 
                    allow="fullscreen">
                </iframe>
            </div>
        `

        setup() {
            // Set page title
            this.headerHtml = '';
            
            // Ensure this is treated as a full-page view
            this.isRoot = true;
        }

        afterRender() {
            super.afterRender();
            
            console.log('IBF Dashboard: Full-page view rendered');
            
            this.loadDashboard();
            this.setupEventListeners();
        }

        setupEventListeners() {
            // Add event listeners for fullscreen buttons
            this.$el.find('[data-action="openFullscreen"]').on('click', () => {
                this.openFullscreen();
            });
            
            this.$el.find('[data-action="closeFullscreen"]').on('click', () => {
                this.closeFullscreen();
            });
        }

        loadDashboard() {
            // Get user token and user ID (same logic as dashlet)
            this.getUserToken().then(token => {
                // Use the same production URL as the dashlet
                const dashboardUrl = 'https://ibf-pivot.510.global';
                const userId = this.getUser().id;
                const iframeUrl = `${dashboardUrl}?espoToken=${token}&espoUserId=${userId}`;
                
                console.log('🔗 Loading IBF Dashboard (full-page) with EspoCRM auth:', {
                    url: iframeUrl,
                    token: token.substring(0, 10) + '...',
                    userId: userId
                });
                
                // Update iframe src and show it
                const iframe = this.$el.find('#ibf-dashboard-main-frame');
                const loadingMessage = this.$el.find('.loading-message');
                
                iframe.attr('src', iframeUrl);
                
                // Show iframe and hide loading message once loaded
                iframe.on('load', () => {
                    loadingMessage.hide();
                    iframe.show();
                });
                
            }).catch(error => {
                console.error('Failed to load IBF Dashboard (full-page):', error);
                this.$el.find('#content').html('<div class="loading-message">Failed to load dashboard</div>');
            });
        }

        getUserToken() {
            return new Promise((resolve, reject) => {
                const authToken = this.getUser().get('token') || 
                                 this.getStorage().get('user', 'auth-token') ||
                                 this.getCookie('auth-token');
                
                if (authToken) {
                    resolve(authToken);
                    return;
                }

                reject(new Error('No authentication token available'));
            });
        }

        getCookie(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        }

        openFullscreen() {
            try {
                // Get current iframe src
                const iframe = this.$el.find('#ibf-dashboard-main-frame');
                const iframeSrc = iframe.attr('src');
                
                if (!iframeSrc) {
                    console.error('IBF Dashboard (full-page): No iframe source found');
                    return;
                }
                
                // Get fullscreen elements
                const overlay = document.getElementById('fullscreen-overlay-main');
                const fullscreenFrame = document.getElementById('fullscreen-frame-main');
                
                if (!overlay || !fullscreenFrame) {
                    console.error('IBF Dashboard (full-page): Fullscreen elements not found');
                    return;
                }
                
                // Copy iframe src to fullscreen iframe
                fullscreenFrame.src = iframeSrc;
                
                // Show overlay
                overlay.style.display = 'block';
                
                // Prevent body scrolling
                document.body.style.overflow = 'hidden';
                
                // Add escape key listener
                this.escapeHandler = (e) => {
                    if (e.key === 'Escape') {
                        this.closeFullscreen();
                    }
                };
                document.addEventListener('keydown', this.escapeHandler);
                
                console.log('IBF Dashboard (full-page): Fullscreen mode activated');
            } catch (error) {
                console.error('IBF Dashboard (full-page): Error in openFullscreen:', error);
            }
        }

        closeFullscreen() {
            try {
                const overlay = document.getElementById('fullscreen-overlay-main');
                const fullscreenFrame = document.getElementById('fullscreen-frame-main');
                
                if (overlay) {
                    overlay.style.display = 'none';
                }
                
                // Restore body scrolling
                document.body.style.overflow = '';
                
                // Remove escape key listener
                if (this.escapeHandler) {
                    document.removeEventListener('keydown', this.escapeHandler);
                    this.escapeHandler = null;
                }
                
                // Clear fullscreen iframe src to save resources
                if (fullscreenFrame) {
                    fullscreenFrame.src = 'about:blank';
                }
                
                console.log('IBF Dashboard (full-page): Fullscreen mode deactivated');
            } catch (error) {
                console.error('IBF Dashboard (full-page): Error in closeFullscreen:', error);
            }
        }
    }
});