<?php

class AfterInstall
{
    protected $container;

    public function run($container)
    {
        $this->container = $container;
        
        // Log successful installation
        error_log("IBF Portal Extension: Installation completed successfully");
        
        // Clear cache to ensure changes take effect
        $this->clearCache();
    }
    
    protected function clearCache()
    {
        try {
            $this->container->get('dataManager')->clearCache();
            error_log("IBF Portal Extension: Cache cleared successfully");
        } catch (\Exception $e) {
            error_log("IBF Portal Extension: Failed to clear cache: " . $e->getMessage());
        }
    }
}
