<?php

class AfterInstall
{
    protected $container;

    public function run($container)
    {
        $this->container = $container;
        
        // Clear cache to ensure changes take effect
        $this->clearCache();
    }

    protected function clearCache()
    {
        try {
            $this->container->get('dataManager')->clearCache();
        } catch (\Exception $e) {}
    }
}
