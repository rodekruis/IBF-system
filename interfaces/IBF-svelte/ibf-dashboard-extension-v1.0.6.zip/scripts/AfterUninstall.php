<?php

class AfterUninstall
{
    protected $container;

    public function run($container)
    {
        $this->container = $container;
        
        // Log successful uninstallation
        error_log("IBF Portal Extension: Uninstallation completed successfully");
        
        // Clear cache to ensure changes take effect
        $this->clearCache();
    }
    
    protected function clearCache()
    {
        try {
            $this->container->get('dataManager')->clearCache();
            error_log("IBF Portal Extension: Cache cleared successfully after uninstall");
        } catch (\Exception $e) {
            error_log("IBF Portal Extension: Failed to clear cache during uninstall: " . $e->getMessage());
        }
    }
}
