var e=r=>r&&r.dir!==""?r.dir.toLowerCase()==="rtl":document?.dir.toLowerCase()==="rtl";export{e as a};
/*! Bundled license information:

@ionic/core/dist/esm/dir-C53feagD.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
