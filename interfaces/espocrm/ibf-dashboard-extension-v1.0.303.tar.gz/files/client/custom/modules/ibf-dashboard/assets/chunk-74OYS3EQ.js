var n=typeof window<"u"?window:void 0,d=typeof document<"u"?document:void 0;export{n as a,d as b};
/*! Bundled license information:

@ionic/core/components/index9.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
