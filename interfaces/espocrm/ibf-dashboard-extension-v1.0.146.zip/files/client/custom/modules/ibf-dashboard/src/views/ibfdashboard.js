define('ibf-dashboard:views/ibfdashboard', ['view'], function (Dep) {

    return Dep.extend({

        template: 'ibf-dashboard:ibfdashboard',

        data: function () {
            return {
                extensionVersion: '1.0.143',
                extensionBuildDate: '2025-07-29',
                countryCode: this.options.countryCode || 'ETH',
                embedPlatform: 'espocrm'
            };
        },

        setup: function () {
            Dep.prototype.setup.call(this);
            
            console.log('IBF Dashboard: View setup started');
            
            // Get country code from options or URL parameters
            this.countryCode = this.options.countryCode || this.getRouterParam('country') || 'ETH';
            
            this.wait(true);
            
            // Load the IBF Dashboard web component
            this.loadWebComponent();
        },

        getRouterParam: function(param) {
            try {
                const router = this.getRouter();
                if (router && router.getCurrentUrl) {
                    const url = router.getCurrentUrl();
                    const urlParams = new URLSearchParams(url.split('?')[1] || '');
                    return urlParams.get(param);
                }
            } catch (e) {
                console.warn('Could not get router param:', e);
            }
            return null;
        },

        loadWebComponent: function () {
            var self = this;
            
            console.log('IBF Dashboard: Loading web component...');
            
            // Check if the web component script is already loaded
            if (window.customElements && window.customElements.get('ibf-dashboard')) {
                console.log('IBF Dashboard: Web component already loaded');
                self.wait(false);
                return;
            }
            
            // Load the web component bundle
            var script = document.createElement('script');
            script.src = this.getBasePath() + 'client/custom/modules/ibf-dashboard/assets/ibf-dashboard-bundle.min.js';
            script.onload = function () {
                console.log('IBF Dashboard: Web component script loaded successfully');
                self.wait(false);
            };
            script.onerror = function (error) {
                console.error('IBF Dashboard: Failed to load web component script', error);
                self.showError('Failed to load IBF Dashboard component');
                self.wait(false);
            };
            
            document.head.appendChild(script);
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            
            console.log('IBF Dashboard: View rendered, initializing web component...');
            
            // Initialize the web component after the view is rendered
            this.initializeWebComponent();
        },

        initializeWebComponent: function () {
            var self = this;
            var attempts = 0;
            var maxAttempts = 50; // 5 seconds max wait time
            
            function tryInitialize() {
                attempts++;
                
                // Wait for the web component to be defined
                if (window.customElements && window.customElements.get('ibf-dashboard')) {
                    console.log('IBF Dashboard: Web component ready, creating element');
                    self.createWebComponentElement();
                } else if (attempts < maxAttempts) {
                    // Retry after a short delay
                    setTimeout(tryInitialize, 100);
                } else {
                    console.error('IBF Dashboard: Web component failed to load after maximum attempts');
                    self.showError('IBF Dashboard component failed to initialize');
                }
            }
            
            tryInitialize();
        },

        createWebComponentElement: function () {
            var container = this.$el.find('#ibf-dashboard-container');
            
            if (container.length > 0) {
                console.log('IBF Dashboard: Creating web component element for country:', this.countryCode);
                
                // Remove loading message
                container.find('.loading-message').remove();
                
                // Create the web component element
                var dashboardElement = document.createElement('ibf-dashboard');
                dashboardElement.setAttribute('country-code', this.countryCode);
                dashboardElement.setAttribute('embed-platform', 'espocrm');
                dashboardElement.style.width = '100%';
                dashboardElement.style.height = '600px';
                dashboardElement.style.border = 'none';
                dashboardElement.style.display = 'block';
                
                // Add error handling
                dashboardElement.addEventListener('error', function(event) {
                    console.error('IBF Dashboard: Web component error:', event);
                });
                
                // Clear container and add the web component
                container.empty();
                container.append(dashboardElement);
                
                console.log('IBF Dashboard: Web component initialized successfully');
                
                // Log version information
                if (window.IBF_DASHBOARD_VERSION) {
                    console.log('IBF Dashboard: Version', window.IBF_DASHBOARD_VERSION);
                }
            } else {
                console.error('IBF Dashboard: Container element not found');
                this.showError('Dashboard container not found');
            }
        },

        showError: function(message) {
            var container = this.$el.find('#ibf-dashboard-container');
            if (container.length > 0) {
                container.html(
                    '<div class="alert alert-danger" style="margin: 20px;">' +
                    '<h4><i class="fas fa-exclamation-triangle"></i> Error</h4>' +
                    '<p>' + message + '</p>' +
                    '</div>'
                );
            }
        },

        getBasePath: function () {
            return this.getConfig().get('siteUrl') || '';
        },

        getHeader: function () {
            return this.translate('IBF Dashboard', 'labels', 'IBFDashboard') + 
                   (this.countryCode ? ' - ' + this.countryCode : '');
        }

    });

});
