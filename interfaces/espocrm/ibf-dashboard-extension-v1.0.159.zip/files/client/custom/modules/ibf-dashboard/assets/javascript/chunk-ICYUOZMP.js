import{a,b}from"./chunk-UFB7CFK7.js";import"./chunk-2R6CW7ES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
