define('custom:modules/ibf-dashboard/views/dashlets/ibf-dashboard', ['views/dashlets/abstract/base'], function (Dep) {
    
    return Dep.extend({

        name: 'IbfDashboard',

        templateContent: `
            <style>
                .dashlet-container,
                .dashlet,
                .dashlet-body {
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                }

                .dashlet-body {
                    position: relative;
                    flex: 1;
                }

                #dashlet-{{id}} .panel-heading {
                    display: none;
                }

                #dashlet-{{id}} .dashlet-body {
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                }

                .web-component-container {
                    flex: 1;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                }

                ibf-dashboard {
                    flex: 1;
                    width: 100%;
                    height: 100%;
                    display: block;
                }

                .loading-container {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 200px;
                    flex-direction: column;
                    gap: 16px;
                }

                .loading-spinner {
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #3498db;
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    animation: spin 2s linear infinite;
                }

                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                .error-container {
                    padding: 20px;
                    text-align: center;
                    color: #e74c3c;
                    background: #fdf2f2;
                    border: 1px solid #fad5d5;
                    border-radius: 4px;
                }

                .fullscreen-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 1000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: background-color 0.3s;
                }

                .fullscreen-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }

                .fullscreen-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 100vh;
                    background: white;
                    z-index: 9999;
                    display: none;
                }

                .fullscreen-overlay .web-component-container {
                    width: 100%;
                    height: 100%;
                }

                .fullscreen-overlay .close-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 10000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }

                .fullscreen-overlay .close-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }
            </style>

            <div class="dashlet-body">
                <button class="fullscreen-button" data-action="openFullscreen">
                    ⛶ Fullscreen
                </button>
                <div class="loading-container" id="loading-{{id}}">
                    <div class="loading-spinner"></div>
                    <div>Loading IBF Dashboard...</div>
                </div>
                <div class="web-component-container" id="dashboard-container-{{id}}" style="display: none;">
                    <ibf-dashboard id="ibf-dashboard-{{id}}"></ibf-dashboard>
                </div>
                <div class="error-container" id="error-{{id}}" style="display: none;">
                    <p>Failed to load IBF Dashboard</p>
                    <p>Please check your connection and try again.</p>
                </div>
            </div>

            <div class="fullscreen-overlay" id="fullscreen-overlay-{{id}}">
                <button class="close-button" data-action="closeFullscreen">
                    ✕ Close
                </button>
                <div class="web-component-container">
                    <ibf-dashboard id="ibf-dashboard-fullscreen-{{id}}"></ibf-dashboard>
                </div>
            </div>
        `,

        init: function () {
            Dep.prototype.init.call(this);
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            
            console.log('🎯 IBF Dashboard Web Component: Initializing dashlet', this.id);
            
            this.setupEventListeners();
            this.loadWebComponentAssets();
        },

        setupEventListeners: function() {
            // Add event listeners for fullscreen buttons
            this.$el.find('[data-action="openFullscreen"]').on('click', () => {
                this.openFullscreen();
            });
            
            this.$el.find('[data-action="closeFullscreen"]').on('click', () => {
                this.closeFullscreen();
            });
        },

        loadWebComponentAssets: function() {
            console.log('🎯 IBF Dashboard Dashlet: Loading web component assets...');
            console.log('   🔍 Checking for existing web components...');
            console.log('   - window.customElements exists:', !!window.customElements);
            console.log('   - ibf-dashboard already defined:', !!(window.customElements && window.customElements.get('ibf-dashboard')));
            
            const assetsBase = '/client/custom/modules/ibf-dashboard/assets';
            console.log('   📁 Assets base:', assetsBase);
            
            // Check if assets are already loaded
            if (window.customElements && window.customElements.get('ibf-dashboard')) {
                console.log('✅ Web component already loaded, initializing dashboard...');
                this.initializeDashboard();
                return;
            }

            // Load CSS first
            this.loadCSS(`${assetsBase}/styles.css`)
                .then(() => {
                    console.log('✅ CSS loaded successfully');
                    // Then load JavaScript (using Angular build output file)
                    return this.loadJS(`${assetsBase}/main.js`);
                })
                .then(() => {
                    console.log('✅ JavaScript loaded successfully');
                    // Wait for web component to be defined
                    return this.waitForWebComponent();
                })
                .then(() => {
                    console.log('✅ Web component ready, initializing dashboard...');
                    this.initializeDashboard();
                })
                .catch(error => {
                    console.error('❌ Failed to load web component assets:', error);
                    this.showError('Failed to load dashboard assets');
                });
        },

        loadCSS: function(url) {
            return new Promise((resolve, reject) => {
                // Check if CSS is already loaded
                const existingLink = document.querySelector(`link[href="${url}"]`);
                if (existingLink) {
                    resolve();
                    return;
                }

                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = url;
                link.onload = () => resolve();
                link.onerror = () => reject(new Error(`Failed to load CSS: ${url}`));
                document.head.appendChild(link);
            });
        },

        loadJS: function(url) {
            console.log('   📦 Loading JavaScript from:', url);
            return new Promise((resolve, reject) => {
                // Check if script is already loaded
                const existingScript = document.querySelector(`script[src="${url}"]`);
                if (existingScript) {
                    console.log('   ⚠️  Script already exists in DOM:', existingScript);
                    resolve();
                    return;
                }

                const script = document.createElement('script');
                script.src = url;
                script.type = 'module';
                
                console.log('   🔧 Script type set to:', script.type);
                console.log('   ➕ Adding script to document head...');
                
                script.onload = () => {
                    console.log('   ✅ Script loaded successfully from:', url);
                    resolve();
                };
                script.onerror = () => {
                    console.error('   ❌ Failed to load script from:', url);
                    reject(new Error(`Failed to load JavaScript: ${url}`));
                };
                document.head.appendChild(script);
            });
        },

        waitForWebComponent: function() {
            console.log('   ⏳ Waiting for web component to be defined...');
            return new Promise((resolve, reject) => {
                let attempts = 0;
                const maxAttempts = 50; // 5 seconds total (100ms * 50)
                
                const checkComponent = () => {
                    attempts++;
                    console.log(`   🔍 Checking web component... attempt ${attempts}/${maxAttempts}`);
                    
                    if (window.customElements && window.customElements.get('ibf-dashboard')) {
                        console.log('   ✅ Web component found and defined!');
                        resolve();
                    } else if (attempts >= maxAttempts) {
                        console.error('   ❌ Web component failed to register within timeout');
                        reject(new Error('Web component failed to register within timeout'));
                    } else {
                        console.log('   ⏳ Web component not yet defined, retrying...');
                        setTimeout(checkComponent, 100);
                    }
                };
                
                checkComponent();
            });
        },

        initializeDashboard: function() {
            this.getUserToken().then(token => {
                const userId = this.getUser().id;
                const parentUrl = window.location.origin + window.location.pathname;
                
                console.log('🔗 Initializing IBF Dashboard with authentication:', {
                    token: token.substring(0, 10) + '...',
                    userId: userId,
                    parentUrl: parentUrl
                });

                // Hide loading and show dashboard
                this.$el.find(`#loading-${this.id}`).hide();
                this.$el.find(`#dashboard-container-${this.id}`).show();

                // Configure the web component
                const dashboard = this.$el.find(`#ibf-dashboard-${this.id}`).get(0);
                if (dashboard) {
                    // Set authentication attributes
                    dashboard.setAttribute('espo-token', token);
                    dashboard.setAttribute('espo-user-id', userId);
                    dashboard.setAttribute('parent-url', parentUrl);
                    dashboard.setAttribute('environment', 'production');
                    
                    console.log('✅ IBF Dashboard web component initialized with EspoCRM auth');
                } else {
                    console.error('❌ Dashboard web component element not found');
                    this.showError('Dashboard component not found');
                }
            }).catch(error => {
                console.error('❌ Failed to get user token:', error);
                this.showError('Authentication failed');
            });
        },

        loadDashboard: function () {
            // This method is kept for compatibility but now handled by initializeDashboard
            console.log('⚠️ loadDashboard called but handled by initializeDashboard');
        },

        getUserToken: function () {
            return new Promise((resolve, reject) => {
                const authToken = this.getUser().get('token') || 
                                 this.getStorage().get('user', 'auth-token') ||
                                 this.getCookie('auth-token');
                
                if (authToken) {
                    resolve(authToken);
                    return;
                }

                reject(new Error('No authentication token available'));
            });
        },

        getCookie: function(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        },

        showError: function(message) {
            console.error('IBF Dashboard Error:', message);
            this.$el.find(`#loading-${this.id}`).hide();
            this.$el.find(`#dashboard-container-${this.id}`).hide();
            this.$el.find(`#error-${this.id}`).show();
        },

        openFullscreen: function() {
            try {
                const overlay = this.$el.find('.fullscreen-overlay').get(0);
                if (!overlay) {
                    console.error('IBF Dashboard: Fullscreen overlay not found');
                    return;
                }

                // Get the current dashboard's authentication attributes
                const mainDashboard = this.$el.find(`#ibf-dashboard-${this.id}`).get(0);
                const fullscreenDashboard = this.$el.find(`#ibf-dashboard-fullscreen-${this.id}`).get(0);
                
                if (mainDashboard && fullscreenDashboard) {
                    // Copy attributes from main dashboard to fullscreen dashboard
                    const token = mainDashboard.getAttribute('espo-token');
                    const userId = mainDashboard.getAttribute('espo-user-id');
                    const parentUrl = mainDashboard.getAttribute('parent-url');
                    const environment = mainDashboard.getAttribute('environment');
                    
                    if (token) fullscreenDashboard.setAttribute('espo-token', token);
                    if (userId) fullscreenDashboard.setAttribute('espo-user-id', userId);
                    if (parentUrl) fullscreenDashboard.setAttribute('parent-url', parentUrl);
                    if (environment) fullscreenDashboard.setAttribute('environment', environment);
                }
                
                // Show overlay
                overlay.style.display = 'block';
                
                // Prevent body scrolling
                document.body.style.overflow = 'hidden';
                
                // Add escape key listener
                this.escapeHandler = (e) => {
                    if (e.key === 'Escape') {
                        this.closeFullscreen();
                    }
                };
                document.addEventListener('keydown', this.escapeHandler);
                
                console.log('IBF Dashboard: Fullscreen mode activated');
            } catch (error) {
                console.error('IBF Dashboard: Error in openFullscreen:', error);
            }
        },

        closeFullscreen: function() {
            try {
                const overlay = this.$el.find('.fullscreen-overlay').get(0);
                if (overlay) {
                    overlay.style.display = 'none';
                } else {
                    console.warn('IBF Dashboard: Fullscreen overlay not found for closing');
                }
                
                // Restore body scrolling
                document.body.style.overflow = '';
                
                // Remove escape key listener
                if (this.escapeHandler) {
                    document.removeEventListener('keydown', this.escapeHandler);
                    this.escapeHandler = null;
                }
                
                console.log('IBF Dashboard: Fullscreen mode deactivated');
            } catch (error) {
                console.error('IBF Dashboard: Error in closeFullscreen:', error);
            }
        }
    });
});