import{b as s}from"./chunk-EOLXYSZT.js";import{f as r,i as c,m as o,n as a}from"./chunk-RUGFDS43.js";import"./chunk-2R6CW7ES.js";var n=":host(.ion-color){color:var(--ion-color-base)}",b=(()=>{let t=class{constructor(e){c(this,e)}render(){let e=r(this);return o(a,{key:"361035eae7b92dc109794348d39bad2f596eb6be",class:s(this.color,{[e]:!0})},o("slot",{key:"c7b8835cf485ba9ecd73298f0529276ce1ea0852"}))}};return t.style=n,t})();export{b as ion_text};
/*! Bundled license information:

@ionic/core/dist/esm/ion-text.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
