define('ibf-dashboard:views/dashlets/ibf-dashboard', ['views/dashlets/abstract/base'], function (Dep) {
    
    return Dep.extend({

        name: 'IbfDashboard',

        templateContent: `
            <style>
                /* Keep EspoCRM header but optimize dashlet spacing */
                .dashlet-container,
                .dashlet,
                .dashlet-body {
                    height: calc(100vh - 150px) !important;
                    width: 100%;
                    display: flex;
                    flex-direction: column;
                    overflow: hidden;
                }

                /* Remove dashlet panel styling to maximize space */
                #dashlet-{{id}} .panel {
                    margin: 0;
                    border: none;
                    box-shadow: none;
                }

                #dashlet-{{id}} .panel-body {
                    padding: 0;
                }

                #dashlet-{{id}} .panel-heading {
                    display: none;
                }

                #dashlet-{{id}} .dashlet-body {
                    height: 100%;
                    width: 100%;
                    display: flex;
                    flex-direction: column;
                    padding: 0;
                    margin: 0;
                    overflow: hidden;
                    background: white;
                }

                /* Web Component Styling */
                .web-component-container {
                    height: 100%;
                    width: 100%;
                    background: white;
                    position: relative;
                    flex: 1;
                }

                ibf-dashboard {
                    display: block;
                    height: 100%;
                    width: 100%;
                    opacity: 0;
                    transition: opacity 0.3s ease-in-out;
                }

                ibf-dashboard.loaded {
                    opacity: 1;
                }

                /* Loading container */
                .loading-container {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    background: white;
                    z-index: 100;
                }

                .loading-spinner {
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid #3498db;
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    animation: spin 2s linear infinite;
                    margin-bottom: 16px;
                }

                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                .loading-message {
                    font-size: 18px;
                    color: #666;
                }

                /* Error message styling */
                .error-container {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    font-size: 16px;
                    color: #d32f2f;
                    background: white;
                    z-index: 100;
                    padding: 20px;
                    text-align: center;
                }

                .error-container h3 {
                    color: #d32f2f;
                    margin-bottom: 10px;
                }

                .error-container button {
                    margin-top: 20px;
                    padding: 10px 20px;
                    background: #c8102e;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .error-container button:hover {
                    background: #a00e26;
                }

                .fullscreen-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 1000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: background-color 0.3s;
                }

                .fullscreen-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }

                .fullscreen-overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100vw;
                    height: 100vh;
                    background: white;
                    z-index: 9999;
                    display: none;
                    overflow: hidden;
                }

                .fullscreen-overlay .web-component-container {
                    height: 100%;
                    width: 100%;
                    background: white;
                }

                .fullscreen-overlay .close-button {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    z-index: 10000;
                    background: rgba(0, 0, 0, 0.7);
                    color: white;
                    border: none;
                    padding: 8px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                }

                .fullscreen-overlay .close-button:hover {
                    background: rgba(0, 0, 0, 0.9);
                }
            </style>

            <div class="dashlet-body">
                <button class="fullscreen-button" data-action="openFullscreen">
                    ⛶ Fullscreen
                </button>
                
                <div class="loading-container" id="loading-container-{{id}}">
                    <div class="loading-spinner"></div>
                    <div class="loading-message">Loading IBF Dashboard...</div>
                </div>
                
                <div class="web-component-container" id="dashboard-container-{{id}}" style="display: none;">
                    <ibf-dashboard 
                        id="ibf-dashboard-component-{{id}}"
                        platform="espocrm"
                        country-code="ETH"
                        disaster-type="drought"
                        theme="auto"
                        language="en"
                        features='["maps", "alerts", "indicators"]'>
                    </ibf-dashboard>
                </div>
                
                <div class="error-container" id="error-container-{{id}}" style="display: none;">
                    <h3>IBF Dashboard Error</h3>
                    <p id="error-message-{{id}}">Failed to load dashboard</p>
                    <button onclick="window.location.reload()">Reload Page</button>
                </div>
            </div>

            <div class="fullscreen-overlay" id="fullscreen-overlay-{{id}}">
                <button class="close-button" data-action="closeFullscreen">
                    ✕ Close
                </button>
                <div class="web-component-container">
                    <ibf-dashboard 
                        id="fullscreen-dashboard-{{id}}"
                        platform="espocrm"
                        country-code="ETH"
                        disaster-type="drought"
                        theme="auto"
                        language="en"
                        features='["maps", "alerts", "indicators"]'>
                    </ibf-dashboard>
                </div>
            </div>
        `,

        init: function () {
            Dep.prototype.init.call(this);
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            
            // Debug: Log the dashlet ID to help with troubleshooting
            console.log('IBF Dashboard: Dashlet ID is:', this.id);
            console.log('IBF Dashboard: Expected overlay ID:', 'fullscreen-overlay-' + this.id);
            console.log('IBF Dashboard: Expected dashboard ID:', 'ibf-dashboard-component-' + this.id);
            
            this.loadWebComponentAssets().then(() => {
                this.initializeDashboard();
            }).catch(error => {
                console.error('Failed to load web component assets:', error);
                this.showError('Failed to load dashboard assets');
            });
            
            this.setupEventListeners();
        },

        async loadWebComponentAssets() {
            console.log('📦 Loading IBF Dashboard web component assets...');
            console.log('   🔍 Checking for existing web components...');
            console.log('   - window.customElements exists:', !!window.customElements);
            console.log('   - ibf-dashboard already defined:', !!(window.customElements && window.customElements.get('ibf-dashboard')));
            
            // Check if assets are already loaded
            if (window.customElements && window.customElements.get('ibf-dashboard')) {
                console.log('✅ Web component already loaded');
                return;
            }
            
            // Get the base URL for assets
            const baseUrl = this.getConfig().get('siteUrl') || window.location.origin;
            const assetsPath = `${baseUrl}/client/custom/modules/ibf-dashboard/assets`;
            console.log('   📁 Assets path:', assetsPath);
            
            // Set global asset base path for Angular application
            window.IBF_DASHBOARD_ASSET_BASE_PATH = `${assetsPath}/`;
            console.log('   🌐 Set global asset base path:', window.IBF_DASHBOARD_ASSET_BASE_PATH);
            
            // Set webpack public path for Angular asset loading
            window.__webpack_public_path__ = `${assetsPath}/`;
            console.log('   🔧 Set webpack public path:', window.__webpack_public_path__);
            
            // Load CSS (using Angular build output file)
            const cssLink = document.createElement('link');
            cssLink.rel = 'stylesheet';
            cssLink.href = `${assetsPath}/styles.css`;
            document.head.appendChild(cssLink);
            console.log('   🎨 CSS loaded from:', cssLink.href);
            
            // Load JavaScript bundle (using Angular build output file)
            return new Promise((resolve, reject) => {
                const script = document.createElement('script');
                script.src = `${assetsPath}/main.js`;
                script.type = 'module';
                
                console.log('   📦 Loading bundle from:', script.src);
                console.log('   🔧 Script type set to:', script.type);
                
                script.onload = () => {
                    console.log('✅ IBF Dashboard web component bundle loaded successfully');
                    console.log('   - Checking if ibf-dashboard is now defined:', !!(window.customElements && window.customElements.get('ibf-dashboard')));
                    // Wait for web component to be defined
                    this.waitForWebComponent().then(resolve).catch(reject);
                };
                
                script.onerror = (error) => {
                    console.error('❌ Failed to load IBF Dashboard web component bundle:', error);
                    reject(error);
                };
                
                document.head.appendChild(script);
                console.log('   ➕ Script element added to document head');
            });
        },

        waitForWebComponent() {
            console.log('   ⏳ Waiting for web component to be registered...');
            return new Promise((resolve, reject) => {
                let attempts = 0;
                const maxAttempts = 50; // 5 seconds total (100ms * 50)
                
                const checkComponent = () => {
                    attempts++;
                    console.log(`   🔍 Check attempt ${attempts}/${maxAttempts}: ibf-dashboard defined = ${!!(window.customElements && window.customElements.get('ibf-dashboard'))}`);
                    
                    if (window.customElements && window.customElements.get('ibf-dashboard')) {
                        console.log('   ✅ Web component successfully registered');
                        resolve();
                    } else if (attempts >= maxAttempts) {
                        console.error('   ❌ Web component registration timeout');
                        reject(new Error('Web component failed to register within timeout'));
                    } else {
                        setTimeout(checkComponent, 100);
                    }
                };
                
                checkComponent();
            });
        },

        initializeDashboard: function () {
            console.log('Initializing IBF Dashboard web component...');
            
            // Get server configuration
            Espo.Ajax.getRequest('IBFDashboard').then(serverResponse => {
                // Get authentication details
                this.getUserToken().then(token => {
                    const userId = this.getUser().id;
                    const userEmail = this.getUser().get('emailAddress');
                    const userName = this.getUser().get('name');
                    
                    console.log('🔗 Configuring IBF Dashboard web component with EspoCRM auth:', {
                        userId: userId,
                        userEmail: userEmail,
                        userName: userName,
                        token: token.substring(0, 10) + '...',
                        ibfBackendApiUrl: serverResponse.ibfBackendApiUrl,
                        ibfGeoserverUrl: serverResponse.ibfGeoserverUrl
                    });
                    
                    // Configure the web component
                    const dashboard = this.$el.find('#ibf-dashboard-component-' + this.id)[0];
                    const loadingContainer = this.$el.find('#loading-container-' + this.id);
                    const dashboardContainer = this.$el.find('#dashboard-container-' + this.id);
                    
                    if (dashboard) {
                        // Set authentication attributes
                        dashboard.setAttribute('espo-token', token);
                        dashboard.setAttribute('espo-user-id', userId);
                        dashboard.setAttribute('espo-user-email', userEmail || '');
                        dashboard.setAttribute('espo-user-name', userName || '');
                        
                        // Set API configuration
                        if (serverResponse.ibfBackendApiUrl) {
                            dashboard.setAttribute('api-url', serverResponse.ibfBackendApiUrl);
                        }
                        if (serverResponse.ibfGeoserverUrl) {
                            dashboard.setAttribute('geoserver-url', serverResponse.ibfGeoserverUrl);
                        }
                        
                        // Set up event listeners
                        dashboard.addEventListener('dashboardReady', (event) => {
                            console.log('✅ IBF Dashboard web component ready:', event.detail);
                            loadingContainer.hide();
                            dashboardContainer.show();
                            $(dashboard).addClass('loaded');
                        });
                        
                        dashboard.addEventListener('error', (event) => {
                            console.error('❌ IBF Dashboard web component error:', event.detail);
                            this.showError('Dashboard failed to initialize: ' + (event.detail?.message || 'Unknown error'));
                        });
                        
                        console.log('✅ IBF Dashboard web component initialized with EspoCRM auth');
                    } else {
                        console.error('❌ Dashboard web component element not found');
                        this.showError('Dashboard component not found');
                    }
                }).catch(error => {
                    console.error('Failed to get user token for IBF Dashboard:', error);
                    this.showError('Authentication failed');
                });
                
            }).catch(error => {
                console.error('Failed to load IBF Dashboard configuration:', error);
                this.showError('Failed to load configuration');
            });
        },

        showError: function(message) {
            console.error('IBF Dashboard Error:', message);
            const loadingContainer = this.$el.find('#loading-container-' + this.id);
            const dashboardContainer = this.$el.find('#dashboard-container-' + this.id);
            const errorContainer = this.$el.find('#error-container-' + this.id);
            const errorMessage = this.$el.find('#error-message-' + this.id);
            
            loadingContainer.hide();
            dashboardContainer.hide();
            errorContainer.show();
            errorMessage.text(message);
        },

        setupEventListeners: function() {
            // Add event listeners for fullscreen buttons
            this.$el.find('[data-action="openFullscreen"]').on('click', () => {
                this.openFullscreen();
            });
            
            this.$el.find('[data-action="closeFullscreen"]').on('click', () => {
                this.closeFullscreen();
            });
        },

        getUserToken: function () {
            return new Promise((resolve, reject) => {
                const authToken = this.getUser().get('token') || 
                                 this.getStorage().get('user', 'auth-token') ||
                                 this.getCookie('auth-token');
                
                if (authToken) {
                    resolve(authToken);
                    return;
                }

                reject(new Error('No authentication token available'));
            });
        },

        getCookie: function(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) return parts.pop().split(';').shift();
        },

        openFullscreen: function() {
            try {
                // Find fullscreen elements
                const overlay = this.$el.find('#fullscreen-overlay-' + this.id)[0];
                const fullscreenDashboard = this.$el.find('#fullscreen-dashboard-' + this.id)[0];
                const mainDashboard = this.$el.find('#ibf-dashboard-component-' + this.id)[0];
                
                if (!overlay) {
                    console.error('IBF Dashboard: Fullscreen overlay not found');
                    return;
                }
                
                if (!fullscreenDashboard) {
                    console.error('IBF Dashboard: Fullscreen dashboard component not found');
                    return;
                }
                
                if (!mainDashboard) {
                    console.error('IBF Dashboard: Main dashboard component not found');
                    return;
                }
                
                // Copy attributes from main dashboard to fullscreen dashboard
                const attributes = mainDashboard.attributes;
                for (let i = 0; i < attributes.length; i++) {
                    const attr = attributes[i];
                    if (attr.name !== 'id') {  // Don't copy the ID
                        fullscreenDashboard.setAttribute(attr.name, attr.value);
                    }
                }
                
                // Show overlay
                overlay.style.display = 'block';
                
                // Prevent body scrolling
                document.body.style.overflow = 'hidden';
                
                // Add escape key listener
                this.escapeHandler = (e) => {
                    if (e.key === 'Escape') {
                        this.closeFullscreen();
                    }
                };
                document.addEventListener('keydown', this.escapeHandler);
                
                console.log('IBF Dashboard: Fullscreen mode activated with web component');
            } catch (error) {
                console.error('IBF Dashboard: Error in openFullscreen:', error);
            }
        },

        closeFullscreen: function() {
            try {
                // Find fullscreen overlay
                const overlay = this.$el.find('#fullscreen-overlay-' + this.id)[0];
                
                if (overlay) {
                    overlay.style.display = 'none';
                } else {
                    console.warn('IBF Dashboard: Fullscreen overlay not found for closing');
                }
                
                // Restore body scrolling
                document.body.style.overflow = '';
                
                // Remove escape key listener
                if (this.escapeHandler) {
                    document.removeEventListener('keydown', this.escapeHandler);
                    this.escapeHandler = null;
                }
                
                console.log('IBF Dashboard: Fullscreen mode deactivated');
            } catch (error) {
                console.error('IBF Dashboard: Error in closeFullscreen:', error);
            }
        }
    });
});