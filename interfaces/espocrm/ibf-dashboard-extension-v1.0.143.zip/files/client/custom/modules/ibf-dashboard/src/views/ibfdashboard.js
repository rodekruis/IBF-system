define(['view'], (View) => {

    return class extends View {

        // Use inline template for full control
        templateContent = `
            <style>
                /* Override EspoCRM layout constraints for full width/height */
                body {
                    overflow: hidden !important;
                }

                #header {
                    position: relative !important;
                    z-index: 1000;
                }

                .container.content {
                    max-width: none !important;
                    padding-left: 0 !important;
                    padding-right: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    height: calc(100vh - 60px) !important; /* Account for header */
                    position: fixed !important;
                    top: 60px !important; /* Header height */
                    left: 0 !important;
                    overflow: hidden !important;
                }

                #main {
                    padding: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    height: 100% !important;
                }

                #content {
                    height: 100% !important;
                    width: 100% !important;
                    position: relative;
                    padding: 0 !important;
                    margin: 0 !important;
                    background: white;
                }

                /* Web Component Styling */
                .dashboard-container {
                    height: 100%;
                    width: 100%;
                    background: white;
                    position: relative;
                }

                ibf-dashboard {
                    display: block;
                    height: 100%;
                    width: 100%;
                    opacity: 0;
                    transition: opacity 0.3s ease-in-out;
                }

                ibf-dashboard.loaded {
                    opacity: 1;
                }

                .loading-message {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 18px;
                    color: #666;
                    background: white;
                    z-index: 100;
                    transition: opacity 0.3s ease-in-out;
                }

                .loading-message.hidden {
                    opacity: 0;
                    pointer-events: none;
                }

                /* Error message styling */
                .error-message {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    font-size: 16px;
                    color: #d32f2f;
                    background: white;
                    z-index: 100;
                    padding: 20px;
                    text-align: center;
                }

                .error-message h3 {
                    color: #d32f2f;
                    margin-bottom: 10px;
                }

                .error-message button {
                    margin-top: 20px;
                    padding: 10px 20px;
                    background: #c8102e;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }

                .error-message button:hover {
                    background: #a00e26;
                }
            </style>
            
            <div id="content">
                <div class="loading-message">Loading IBF Dashboard...</div>
                <div class="dashboard-container">
                    <ibf-dashboard 
                        id="ibf-dashboard-component"
                        platform="espocrm"
                        country-code="ETH"
                        disaster-type="drought"
                        theme="auto"
                        language="en"
                        features='["maps", "alerts", "indicators"]'>
                    </ibf-dashboard>
                </div>
            </div>
        `

        setup() {
            // Set page title
            this.headerHtml = '';
            
            // Ensure this is treated as a full-page view
            this.isRoot = true;
            
            // Extension version information
            this.extensionVersion = '0.321.4';
            this.extensionBuildDate = '2025-07-29';
            
            // Log extension version information
            console.log('🔥 IBF Dashboard EspoCRM Extension Information:');
            console.log(`   📦 Extension Version: v${this.extensionVersion}`);
            console.log(`   📅 Build Date: ${this.extensionBuildDate}`);
            console.log(`   🏢 Platform: EspoCRM Integration`);
            console.log(`   👤 Author: 510 Global`);
        }

        afterRender() {
            super.afterRender();
            
            console.log('IBF Dashboard: Full-page web component view rendered');
            
            this.loadWebComponentAssets().then(() => {
                this.initializeDashboard();
            }).catch(error => {
                console.error('Failed to load web component assets:', error);
                this.showError('Failed to load dashboard assets');
            });
        }

        async loadWebComponentAssets() {
            console.log('📦 Loading IBF Dashboard web component assets...');
            console.log('   � Using optimized IIFE bundle with proper module isolation');
            console.log('   �🔍 Checking for existing web components...');
            console.log('   - window.customElements exists:', !!window.customElements);
            console.log('   - ibf-dashboard already defined:', !!(window.customElements && window.customElements.get('ibf-dashboard')));
            
            // Get the base URL for assets
            const baseUrl = this.getConfig().get('siteUrl') || window.location.origin;
            const assetsPath = `${baseUrl}/client/custom/modules/ibf-dashboard/assets`;
            console.log('   📁 Assets path:', assetsPath);
            
            // Set global asset base path for Angular application
            window.IBF_DASHBOARD_ASSET_BASE_PATH = `${assetsPath}/`;
            console.log('   🌐 Set global asset base path:', window.IBF_DASHBOARD_ASSET_BASE_PATH);
            
            // Set webpack public path for Angular asset loading
            window.__webpack_public_path__ = `${assetsPath}/`;
            console.log('   🔧 Set webpack public path:', window.__webpack_public_path__);
            
            // Load CSS first (using bundle file)
            const cssLink = document.createElement('link');
            cssLink.rel = 'stylesheet';
            cssLink.href = `${assetsPath}/ibf-dashboard.css`;
            document.head.appendChild(cssLink);
            console.log('   🎨 CSS loaded from:', cssLink.href);
            
            // Load JavaScript bundle (using optimized bundle file)
            return new Promise((resolve, reject) => {
                const script = document.createElement('script');
                script.src = `${assetsPath}/ibf-dashboard-bundle.min.js`;
                script.type = 'text/javascript';
                
                console.log('   📦 Loading optimized bundle from:', script.src);
                console.log('   🔧 Script type set to:', script.type);
                
                script.onload = () => {
                    console.log('✅ IBF Dashboard optimized web component bundle loaded successfully');
                    console.log(`   🔥 EspoCRM Extension v${this.extensionVersion} (${this.extensionBuildDate})`);
                    console.log('   - Bundle uses IIFE module isolation to prevent JavaScript conflicts');
                    console.log('   - Checking if ibf-dashboard is now defined:', !!(window.customElements && window.customElements.get('ibf-dashboard')));
                    
                    // Check for web component version in bundle (dynamically set by bundle)
                    if (window.IBF_DASHBOARD_VERSION) {
                        console.log(`   📦 Web Component Bundle Version: v${window.IBF_DASHBOARD_VERSION}`);
                        if (window.IBF_DASHBOARD_BUILD_DATE) {
                            console.log(`   📅 Web Component Build Date: ${window.IBF_DASHBOARD_BUILD_DATE}`);
                        }
                    } else {
                        console.log('   ⚠️ Web Component version information not available');
                    }
                    
                    resolve();
                };
                
                script.onerror = (error) => {
                    console.error('❌ Failed to load IBF Dashboard optimized web component bundle:', error);
                    reject(error);
                };
                
                document.head.appendChild(script);
                console.log('   ➕ Script element added to document head');
            });
        }

        initializeDashboard() {
            console.log('Initializing IBF Dashboard web component...');
            
            // Get server configuration
            Espo.Ajax.getRequest('IBFDashboard').then(serverResponse => {
                // Get authentication details
                this.getUserToken().then(token => {
                    const userId = this.getUser().id;
                    const userEmail = this.getUser().get('emailAddress');
                    const userName = this.getUser().get('name');
                    
                    console.log('🔗 Configuring IBF Dashboard web component with EspoCRM auth:', {
                        userId: userId,
                        userEmail: userEmail,
                        userName: userName,
                        token: token.substring(0, 10) + '...',
                        ibfBackendApiUrl: serverResponse.ibfBackendApiUrl,
                        ibfGeoserverUrl: serverResponse.ibfGeoserverUrl
                    });
                    
                    // Configure the web component
                    const dashboard = this.$el.find('#ibf-dashboard-component')[0];
                    const loadingMessage = this.$el.find('.loading-message');
                    
                    if (dashboard) {
                        // Set authentication attributes
                        dashboard.setAttribute('espo-token', token);
                        dashboard.setAttribute('espo-user-id', userId);
                        dashboard.setAttribute('espo-user-email', userEmail || '');
                        dashboard.setAttribute('espo-user-name', userName || '');
                        
                        // Set API configuration
                        if (serverResponse.ibfBackendApiUrl) {
                            dashboard.setAttribute('api-url', serverResponse.ibfBackendApiUrl);
                        }
                        if (serverResponse.ibfGeoserverUrl) {
                            dashboard.setAttribute('geoserver-url', serverResponse.ibfGeoserverUrl);
                        }
                        
                        // Set up event listeners
                        dashboard.addEventListener('dashboardReady', (event) => {
                            console.log('✅ IBF Dashboard web component ready:', event.detail);
                            loadingMessage.addClass('hidden');
                            $(dashboard).addClass('loaded');
                        });
                        
                        dashboard.addEventListener('error', (event) => {
                            console.error('❌ IBF Dashboard web component error:', event.detail);
                            this.showError('Dashboard failed to initialize: ' + (event.detail?.message || 'Unknown error'));
                        });
                        
                        dashboard.addEventListener('componentLoaded', (event) => {
                            console.log('IBF Dashboard web component loaded:', event.detail);
                        });
                        
                        // Initialize the component
                        if (typeof dashboard.initialize === 'function') {
                            dashboard.initialize();
                        }
                        
                        console.log('✅ IBF Dashboard web component configured successfully');
                    } else {
                        console.error('❌ IBF Dashboard web component element not found');
                        this.showError('Dashboard component not found');
                    }
                }).catch(error => {
                    console.error('Failed to get user token for IBF Dashboard:', error);
                    this.showError('Authentication failed');
                });
                
            }).catch(error => {
                console.error('Failed to load IBF Dashboard configuration:', error);
                // Initialize with fallback configuration
                this.initializeDashboardFallback();
            });
        }

        initializeDashboardFallback() {
            console.log('🔄 Initializing IBF Dashboard with fallback configuration');
            
            this.getUserToken().then(token => {
                const userId = this.getUser().id;
                const userEmail = this.getUser().get('emailAddress');
                const userName = this.getUser().get('name');
                
                console.log('🔗 Configuring IBF Dashboard web component with fallback auth:', {
                    userId: userId,
                    userEmail: userEmail,
                    userName: userName,
                    token: token.substring(0, 10) + '...'
                });
                
                // Configure the web component with fallback settings
                const dashboard = this.$el.find('#ibf-dashboard-component')[0];
                const loadingMessage = this.$el.find('.loading-message');
                
                if (dashboard) {
                    // Set authentication attributes
                    dashboard.setAttribute('espo-token', token);
                    dashboard.setAttribute('espo-user-id', userId);
                    dashboard.setAttribute('espo-user-email', userEmail || '');
                    dashboard.setAttribute('espo-user-name', userName || '');
                    
                    // Set fallback API configuration
                    dashboard.setAttribute('api-url', 'https://ibf-test.510.global/api');
                    dashboard.setAttribute('geoserver-url', 'https://ibf.510.global/geoserver/ibf-system/wms');
                    
                    // Set up event listeners
                    dashboard.addEventListener('dashboardReady', (event) => {
                        console.log('✅ IBF Dashboard web component ready (fallback):', event.detail);
                        loadingMessage.addClass('hidden');
                        $(dashboard).addClass('loaded');
                    });
                    
                    dashboard.addEventListener('error', (event) => {
                        console.error('❌ IBF Dashboard web component error (fallback):', event.detail);
                        this.showError('Dashboard failed to initialize: ' + (event.detail?.message || 'Unknown error'));
                    });
                    
                    // Initialize the component
                    if (typeof dashboard.initialize === 'function') {
                        dashboard.initialize();
                    }
                    
                    console.log('✅ IBF Dashboard web component configured with fallback settings');
                } else {
                    console.error('❌ IBF Dashboard web component element not found');
                    this.showError('Dashboard component not found');
                }
            }).catch(error => {
                console.error('Failed to get user token for IBF Dashboard (fallback):', error);
                this.showError('Authentication failed');
            });
        }

        showError(message) {
            this.$el.find('.loading-message').addClass('hidden');
            this.$el.find('#content').append(`
                <div class="error-message">
                    <h3>IBF Dashboard Error</h3>
                    <p>${message}</p>
                    <button onclick="window.location.reload()">Reload Page</button>
                </div>
            `);
        }

        getUserToken() {
            return new Promise((resolve, reject) => {
                // Get the current user's API token
                Espo.Ajax.getRequest('App/user').then(response => {
                    const token = this.getUser().get('token') || this.getConfig().get('authToken');
                    if (token) {
                        resolve(token);
                    } else {
                        reject(new Error('No authentication token found'));
                    }
                }).catch(reject);
            });
        }
    };

});
