<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CItem extends \Espo\Core\Templates\Controllers\Base
{
}
