<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CRegion extends \Espo\Core\Templates\Controllers\Base
{
}
