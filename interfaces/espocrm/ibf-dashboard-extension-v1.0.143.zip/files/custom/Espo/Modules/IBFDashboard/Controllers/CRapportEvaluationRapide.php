<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CRapportEvaluationRapide extends \Espo\Core\Templates\Controllers\Base
{
}
