<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CFlood extends \Espo\Core\Templates\Controllers\Base
{
}
