<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CCommunes extends \Espo\Core\Templates\Controllers\Base
{
}
