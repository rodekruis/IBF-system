<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CWarehouse extends \Espo\Core\Templates\Controllers\Base
{
}
