<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CActivities extends \Espo\Core\Templates\Controllers\BasePlus
{
}
