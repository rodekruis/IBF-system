<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CProgram extends \Espo\Core\Templates\Controllers\BasePlus
{
}
