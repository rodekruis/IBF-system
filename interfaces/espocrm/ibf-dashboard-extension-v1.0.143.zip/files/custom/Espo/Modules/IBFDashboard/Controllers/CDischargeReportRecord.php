<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CDischargeReportRecord extends \Espo\Core\Templates\Controllers\Base
{
}
