<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CBranch extends \Espo\Core\Templates\Controllers\BasePlus
{
}
