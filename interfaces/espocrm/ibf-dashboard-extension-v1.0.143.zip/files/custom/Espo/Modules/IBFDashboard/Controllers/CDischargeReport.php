<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CDischargeReport extends \Espo\Core\Templates\Controllers\Base
{
}
