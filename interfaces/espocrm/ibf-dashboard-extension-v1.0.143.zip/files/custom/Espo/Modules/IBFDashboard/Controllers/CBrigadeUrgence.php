<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CBrigadeUrgence extends \Espo\Core\Templates\Controllers\Base
{
}
