<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CEpidemics extends \Espo\Core\Templates\Controllers\BasePlus
{
}
