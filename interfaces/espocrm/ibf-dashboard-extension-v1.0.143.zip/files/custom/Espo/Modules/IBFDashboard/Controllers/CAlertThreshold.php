<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CAlertThreshold extends \Espo\Core\Templates\Controllers\BasePlus
{
}
