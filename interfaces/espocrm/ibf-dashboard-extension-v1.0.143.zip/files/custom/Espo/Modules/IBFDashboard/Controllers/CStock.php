<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CStock extends \Espo\Core\Templates\Controllers\BasePlus
{
}
