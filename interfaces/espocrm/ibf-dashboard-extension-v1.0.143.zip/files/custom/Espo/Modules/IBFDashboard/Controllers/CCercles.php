<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CCercles extends \Espo\Core\Templates\Controllers\Base
{
}
