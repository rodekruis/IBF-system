<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CActivity extends \Espo\Core\Templates\Controllers\Event
{
}
