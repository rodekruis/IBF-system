<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CHazard extends \Espo\Core\Templates\Controllers\Base
{
}
