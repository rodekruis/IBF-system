<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CRiverStation extends \Espo\Core\Templates\Controllers\Base
{
}
