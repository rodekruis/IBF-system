<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CNeedsAssessment extends \Espo\Core\Templates\Controllers\Base
{
}
