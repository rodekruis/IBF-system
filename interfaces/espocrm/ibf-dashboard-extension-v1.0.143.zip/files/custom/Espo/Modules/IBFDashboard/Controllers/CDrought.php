<?php

namespace Espo\Modules\IBFDashboard\Controllers;

class CDrought extends \Espo\Core\Templates\Controllers\BasePlus
{
}
