define('ibf-dashboard:views/ibfdashboard', ['view'], function (Dep) {

    return Dep.extend({

        template: 'ibf-dashboard:ibf-dashboard',

        data: function () {
            return {
                extensionVersion: '1.0.143',
                extensionBuildDate: '2025-07-29',
                countryCode: this.options.countryCode || 'ETH',
                embedPlatform: 'espocrm'
            };
        },

        setup: function () {
            Dep.prototype.setup.call(this);
            console.log('IBF Dashboard: View setup started');
            
            // Get country code from options or URL parameters
            this.countryCode = this.options.countryCode || this.getRouterParam('country') || 'ETH';
        },

        getRouterParam: function(param) {
            try {
                const router = this.getRouter();
                if (router && router.getCurrentUrl) {
                    const url = router.getCurrentUrl();
                    const urlParams = new URLSearchParams(url.split('?')[1] || '');
                    return urlParams.get(param);
                }
            } catch (e) {
                console.warn('Could not get router param:', e);
            }
            return null;
        },

        afterRender: function () {
            Dep.prototype.afterRender.call(this);
            console.log('IBF Dashboard: View rendered, template JavaScript will handle web component initialization');
        },

        getHeader: function () {
            return this.translate('IBF Dashboard', 'labels', 'IBFDashboard') + 
                   (this.countryCode ? ' - ' + this.countryCode : '');
        }

    });

});
