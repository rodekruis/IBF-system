import{b as a,c}from"./chunk-4QXQ3E7J.js";import{c as r,d as s}from"./chunk-RGXYJBLP.js";import{a as i}from"./chunk-IIGIEWRB.js";import"./chunk-DTON4BNA.js";import{g as n}from"./chunk-2R6CW7ES.js";var h=()=>{let e=window;e.addEventListener("statusTap",()=>{r(()=>{let m=e.innerWidth,d=e.innerHeight,o=document.elementFromPoint(m/2,d/2);if(!o)return;let t=a(o);t&&new Promise(l=>i(t,l)).then(()=>{s(()=>n(null,null,function*(){t.style.setProperty("--overflow","hidden"),yield c(t,300),t.style.removeProperty("--overflow")}))})})})};export{h as startStatusTap};
/*! Bundled license information:

@ionic/core/components/status-tap.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
