import{a as r}from"./chunk-PJKO2XHO.js";var n=()=>{if(r!==void 0)return r.Capacitor};export{n as a};
/*! Bundled license information:

@ionic/core/dist/esm/capacitor-CFERIeaU.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
