import{i as s,m as e,n}from"./chunk-RUGFDS43.js";import"./chunk-2R6CW7ES.js";var a=":host{scroll-snap-align:center;scroll-snap-stop:always;-ms-flex-negative:0;flex-shrink:0;width:100%;overflow-y:scroll;scrollbar-width:none;-ms-overflow-style:none;}:host::-webkit-scrollbar{display:none}",l=(()=>{let t=class{constructor(o){s(this,o)}render(){return e(n,{key:"db6876f2aee7afa1ea8bc147337670faa68fae1c"},e("slot",{key:"bc05714a973a5655668679033f5809a1da6db8cc"}))}};return t.style=a,t})();export{l as ion_segment_content};
/*! Bundled license information:

@ionic/core/dist/esm/ion-segment-content.entry.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
