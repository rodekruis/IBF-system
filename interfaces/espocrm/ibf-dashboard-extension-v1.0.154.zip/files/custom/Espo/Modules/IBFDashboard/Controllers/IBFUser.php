<?php

namespace Espo\Modules\IBFDashboard\Controllers;

use Espo\Core\Controllers\Record;

class IBFUser extends Record
{
    // Standard entity controller - inherits all CRUD operations from Record
    // No custom implementation needed for basic entity management
}
