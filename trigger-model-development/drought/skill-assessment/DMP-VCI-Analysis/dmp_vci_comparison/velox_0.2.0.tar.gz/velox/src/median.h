#ifndef MEDIAN_H_INCLUDED
#define MEDIAN_H_INCLUDED

#include <vector>
double median(std::vector<double> scores);

#endif
